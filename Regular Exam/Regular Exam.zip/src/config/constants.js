const DB_PASS = "realestatepass";
const DB_NAME = "Exam-DB";
exports.PORT = "3000";
exports.DB_STRING = `mongodb+srv://realestateuser:${DB_PASS}@cluster0.ozv6x.mongodb.net/${DB_NAME}?retryWrites=true&w=majority`;
exports.SECRET = "mEG5sDv4b5i5BtC37MbAxGu6W5gRWeKR";
exports.TOKEN_COOKIE_NAME = "app_token";
